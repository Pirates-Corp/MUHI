export const anonymousUserSchema = {
  $jsonSchema: {
    bsonType: "object"
  },
};
