import Login from "../components/user/Login"
export default function index() {
  return (
    <>
     <Login/>
    </>
  )
}
