import BaseLayout from '../../../components/Layouts/BaseLayout.jsx'
import Accounts from "../../../components/admin/AccountManagement/Accounts"
export default function accounts() {
  return (
    <div>
      <BaseLayout>
      <Accounts/>
      </BaseLayout>
    </div>
  )
}
