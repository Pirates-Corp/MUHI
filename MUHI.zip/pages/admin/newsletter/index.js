import BaseLayout from '../../../components/Layouts/BaseLayout.jsx'
import AdminNewsletterCard from "../../../components/admin/Newsletter/AdminNewsletterCard"

export default function accounts() {
  return (
    <div>
      <BaseLayout>
        <AdminNewsletterCard/>    
      </BaseLayout>
    </div>
  )
}
