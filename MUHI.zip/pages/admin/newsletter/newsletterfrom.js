import BaseLayout from '../../../components/Layouts/BaseLayout.jsx'
import NewsLetterFrom from "../../../components/admin/Newsletter/NewsLetterForm"
export default function accounts() {
  return (
    <div>

      <BaseLayout>
      <NewsLetterFrom/>    
      </BaseLayout>
    </div>
  )
}