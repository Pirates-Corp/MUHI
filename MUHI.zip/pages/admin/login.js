import React from 'react';
import LoginForm from '../../components/admin/adminLogin';


const Login = () => {

    return(
        <div>
            <LoginForm />
        </div>
    )
}

export default Login