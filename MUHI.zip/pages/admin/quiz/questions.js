import React from 'react';

import QuizQuestionsForm from "../../../components/admin/Quiz/QuizQuestionsForm";


const questions = () => {
    

    return(
        <>
           <QuizQuestionsForm />
       </>
    )
}

export default questions;