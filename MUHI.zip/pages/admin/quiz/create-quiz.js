import React from 'react';

import QuizDataForm from "../../../components/admin/Quiz/QuizDataForm";


const createQuiz = () => {
    

    return(
        <>
           <QuizDataForm />
       </>
    )
}

export default createQuiz;