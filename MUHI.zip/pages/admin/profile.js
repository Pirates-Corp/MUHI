import UpdateProfile from '../../components/common/Components/UpdateProfile'
import BaseLayout from '../../components/Layouts/BaseLayout'
export default function profile() {
  return (
   <BaseLayout>
    <UpdateProfile />
   </BaseLayout>
  )
}

