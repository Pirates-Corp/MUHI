import OpenQuiz from "../../components/common/Components/OpenQuiz";


export default function openQuiz(){
    return (
        <>
            <OpenQuiz/>
        </>
      );
}