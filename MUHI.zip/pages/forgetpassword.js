import Forgetpassword from "../components/user/ForgetPassword"
export default function forgetpassword() {
  return (
    <>
     <Forgetpassword/>
    </>
  )
}
