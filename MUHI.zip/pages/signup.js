import Signup from '../components/user/Signup';

export default function signupPage(){
    return (
        <div>
          <Signup/>
        </div>
      );
}