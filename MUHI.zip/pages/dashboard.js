import UserDashboard from "../components/user/UserDashboard"
export default function dashboard() {
  return (
    <>
      <UserDashboard/>
    </>
  )
}

