const NotFound = ()=>{


    return(<h4>404</h4>)
}

export default NotFound;