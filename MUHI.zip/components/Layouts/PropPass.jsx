const PropPass = ({props})=>{
    return <>{props}</>;
}

export default PropPass;